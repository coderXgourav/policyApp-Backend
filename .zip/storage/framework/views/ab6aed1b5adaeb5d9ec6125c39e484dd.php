

<?php echo $__env->make('employeePanel.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(url('assets/signature/signature1.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/signature/signature.css')); ?>">

<style>
  .error{
    color: red;
  }
    .kbw-signature { 
      width: 400px; 
      height: 200px;
    }
    #sig canvas{
        /* width: 100% !important; */
        height: 200px;
    }
</style>

    <!-- Main Content -->
    <main
      :class="[$store.app.sidebar && $store.app.menu=='vertical'?'w-full xl:ltr:ml-[280px] xl:rtl:mr-[280px] xl:w-[calc(100%-280px)]':'w-full',$store.app.sidebar && $store.app.menu=='hovered'?'w-full xl:ltr:ml-[80px] xl:w-[calc(100%-80px)] xl:rtl:mr-[80px]':'w-full', $store.app.menu == 'horizontal' && 'xl:!pt-[118px]', $store.app.contrast=='high'?'bg-neutral-0 dark:bg-neutral-904':'bg-neutral-20 dark:bg-neutral-903']"
      class="w-full text-neutral-700 min-h-screen dark:text-neutral-20 pt-[60px] md:pt-[66px] duration-300">
      <div
        :class="[$store.app.menu=='horizontal' ? 'max-w-[1704px] mx-auto xxl:px-0 xxl:pt-8':'',$store.app.stretch?'xxxl:max-w-[92%] mx-auto':'']"
        class="p-3 md:p-4 xxl:p-6">
        <div x-data="{activeTab:'list'}" class="white-box">
          <div class="flex justify-between items-center bb-dashed-n30">
            <h4>Download Policy Certificate</h4>
          </div>
         
         
        <form id="uploadSignature">
<input type="hidden" name="policy_id" value="<?php echo e($policy->policy_id); ?>">
          <h6 class="text-success" for="checkbox">

            <input type="checkbox" name="check"  required/>  I acknowledge that I have received and reviewed the <?php echo e($policy->policy_title); ?> . I understand the contents of the policy and agree to comply with its requirements and guidelines.
              
             </h6>
             <div class=" bb-dashed-n30" style="display: flex; align-items:center; gap:15px;">
            </div>
          <input type="hidden" id="url" value="/employee/submit-signature">
          <input type="hidden" id="method" value="POST">
          <input type="hidden" id="btnName" value="Save">
          <input type="hidden" name="policy_id" id="" value="<?php echo e($policy->policy_id); ?>">
          <?php echo e(@csrf_field()); ?>

          <?php echo csrf_field(); ?>
          <div class="col-md-12">
              <label class="" for="">Signature</label> <br>
              <br/>
              <div id="sig"></div>
              <br/>
              <textarea id="signature64" name="signed" style="display:none;"></textarea>
          </div>
          <br/>
          <button id="clear" class="btn btn-danger btn-sm">Clear Signature</button>

          <button id="btn" class="btn btn-primary">Save</button> 
      </form>
          
    <div>
      <br>
      <form action="<?php echo e(url('/employee/certificate')); ?>" method="GET">
        <input type="hidden" name="policy_id" id="policy" value="">
        <button style="display:none;" type="submit" id="download" class="btn-primary" >Download Certificate</button>
      </form>
  </div>
        </div>

      </div>
    </main>

  <?php echo $__env->make('employeePanel.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<script src="<?php echo e(url('assets/signature/sig1.js')); ?>"></script>
<script src="<?php echo e(url('assets/signature/sig2.js')); ?>"></script>
<script src="<?php echo e(url('assets/signature/sig3.js')); ?>"></script>

    <script type="text/javascript">
    var sig = $('#sig').signature({syncField: '#signature64', syncFormat: 'PNG'});
    $('#sig').val(sig);
    $('#clear').click(function(e) {
        e.preventDefault();
        sig.signature('clear');
        $("#signature64").val('');
    });
  </script><?php /**PATH D:\PROJECTS\LARAVEL\POLICY\policyApp-Backend\resources\views/employeePanel/dashboard/policy/e_sign_policy.blade.php ENDPATH**/ ?>