<?php echo $__env->make('employeePanel.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .selectForm{
    outline: none;
    border-radius: 8px;
    padding-left: 8px;
    }
    .question_palate{
      background: #1d1e24;
    padding: 20px;
    border-radius: 9px;
    }
    .primary{
      font-size: 14px !important;
    } 
    .selectForm option{
      color: black;
    }

    .selectForm1{
    padding-left: 8px;
        border: 1px solid gray;
    outline: none;
    border-radius: 8px;
    }
    .selectForm1 option{
      color: black;
    }


    .outlineNone{
        outline: none;
    }
    .error{
      color:red;
    }
</style>
    <!-- Main Content -->
    <main
      :class="[$store.app.sidebar && $store.app.menu=='vertical'?'w-full xl:ltr:ml-[280px] xl:rtl:mr-[280px] xl:w-[calc(100%-280px)]':'w-full',$store.app.sidebar && $store.app.menu=='hovered'?'w-full xl:ltr:ml-[80px] xl:w-[calc(100%-80px)] xl:rtl:mr-[80px]':'w-full', $store.app.menu == 'horizontal' && 'xl:!pt-[118px]', $store.app.contrast=='high'?'bg-neutral-0 dark:bg-neutral-904':'bg-neutral-20 dark:bg-neutral-903']"
      class="w-full text-neutral-700 min-h-screen dark:text-neutral-20 pt-[60px] md:pt-[66px] duration-300"
    >
    <form id="form">
      
      <input type="hidden" id="url" value="/employee/submit-mcq">
      <input type="hidden" id="method" value="POST">
      <input type="hidden" id="btnName" value="Submit Test">

      <?php echo e(@csrf_field()); ?>

      <div :class="[$store.app.menu=='horizontal' ? 'max-w-[1704px] mx-auto xxl:px-0 xxl:pt-8':'',$store.app.stretch?'xxxl:max-w-[92%] mx-auto':'']" class="p-3 md:p-4 xxl:p-6">
        <div class="white-box">
          <div style="display: flex;justify-content: space-between">
            <div>
              <h5 class="mb-2 bb-dashed-n30"><?php echo ucfirst($mcq[0]->policy_title); ?> Privacy Policy MCQ Test</h5>
            </div>
            <div>
              <h5 class="mb-2 bb-dashed-n30">Pass Mark - <?php echo e($pass_mark); ?></h5>
            </div>
          </div>
          
          <div class="grid grid-cols-12 gap-4 xxl:gap-6">
            <div class="col-span-12 lg:col-span-10">
              <div class="n20-box">
                <div class="grid grid-cols-2 gap-4 xxl:gap-6 my-6">
                  <?php
                      $no = 1;
                  ?>
                  <?php $__currentLoopData = $mcq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-span-2 question_palate">
                    <p class="l-text font-medium mb-4"> <?php echo e($no++); ?>. <?php echo e($item->question); ?> ? </p>
                    <ul class="flex flex-wrap gap-4">
                      <li>
                        <div>
                          <input type="radio" id="optiona<?php echo e($item->mcq_id); ?>" name="<?php echo e($item->mcq_id); ?>" value="<?php echo e($item->option_a); ?>" required>
                          <label class="primary" for="optiona<?php echo e($item->mcq_id); ?>">(A) <?php echo e($item->option_a); ?></label>
                        </input>
                        </div>
                      </li>
                        <li>
                        <div >
                          <input type="radio" id="optionb<?php echo e($item->mcq_id); ?>" name="<?php echo e($item->mcq_id); ?>"  value="<?php echo e($item->option_b); ?>" required >
                          <label class="primary" for="optionb<?php echo e($item->mcq_id); ?>">(B) <?php echo e($item->option_b); ?></label>
                        </input>
                        </div>
                      </li>
                      <li>
                        <div >
                          <input type="radio" id="optionc<?php echo e($item->mcq_id); ?>" name="<?php echo e($item->mcq_id); ?>"  value="<?php echo e($item->option_c); ?>" required >
                          <label class="primary" for="optionc<?php echo e($item->mcq_id); ?>">(C) <?php echo e($item->option_c); ?></label>
                        </input>
                        </div>
                      </li>
                      <li>
                        <div >
                          <input type="radio" id="optiond<?php echo e($item->mcq_id); ?>" name="<?php echo e($item->mcq_id); ?>"  value="<?php echo e($item->option_d); ?>" required >
                          <label class="primary" for="optiond<?php echo e($item->mcq_id); ?>"> (D) <?php echo e($item->option_d); ?></label>
                        </input>
                        </div>
                      </li>
                    </ul>
                </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                    
      <div>
        
        <input type="hidden" name="policy_id" value="<?php echo e($mcq[0]->policy_id); ?>">

        
        <button type="submit" id="btn" class="btn btn-primary">Submit Test</button>
      </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
    </main>
<?php echo $__env->make('employeePanel.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\PROJECTS\LARAVEL\policyApp\resources\views/employeePanel/dashboard/mcq/mcqpage.blade.php ENDPATH**/ ?>