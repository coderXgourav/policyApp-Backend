<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
  

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="description" content="TechWave">
<meta name="author" content="Frenify">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<title>Sign In - TechWave</title>


<script>
	if (!localStorage.frenify_skin) {
		localStorage.frenify_skin = 'dark';
	}
	if (!localStorage.frenify_panel) {
		localStorage.frenify_panel = '';
	}
	document.documentElement.setAttribute("data-techwave-skin", localStorage.frenify_skin);
	if(localStorage.frenify_panel !== ''){
		document.documentElement.classList.add(localStorage.frenify_panel);
	}
  	
</script>

<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;200;300;400;500;600;700;800;900&amp;family=Work+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
<!-- !Google Fonts -->

<!-- Styles -->
<link type="text/css" rel="stylesheet" href="<?php echo e(url('css/plugins8a54.css?ver=1.0.0')); ?>" />
<link type="text/css" rel="stylesheet" href="<?php echo e(url('css/style8a54.css?ver=1.0.0')); ?>" />
<!--[if lt IE 9]> <script type="text/javascript" src="js/modernizr.custom.js"></script> <![endif]-->
<!-- !Styles -->

</head>

<body>


<!-- Sign In -->
<div class="techwave_fn_sign">
	
	<div class="sign__content">
		<h1 class="logo">Designed by Frenify</h1>
		<form class="login">
			<div class="form__content">
				<div class="form__title">Sign In</div>
				<div class="form__username">
					<label for="user_login">Username or Email</label>
					<input type="text" class="input" id="user_login" autocapitalize="off" autocomplete="username" aria-describedby="login-message">
				</div>
				<div class="form__pass">
					<div class="pass_lab">
						<label for="user_password">Password</label>
						<a href="#">Forget Password?</a>
					</div>
					<input type="password" id="user_password" autocomplete="current-password" spellcheck="false">
				</div>
				<div class="form__submit">
					<label class="fn__submit">
						<input type="submit" name="submit" value="Sign In">
					</label>
				</div>
				<div class="form__alternative">
					<div class="fn__lined_text">
						<div class="line"></div>
						<div class="text">Or</div>
						<div class="line"></div>
					</div>
				</div>
			</div>
		</form>
		
	</div>
	
</div>
<!-- !Sign In -->



<!-- Scripts -->
<script type="text/javascript" src="<?php echo e(url('js/jquery8a54.js?ver=1.0.0')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/plugins8a54.js?ver=1.0.0')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/init8a54.js?ver=1.0.0')); ?>"></script>
<!-- !Scripts -->

</body>

</html><?php /**PATH C:\xampp\htdocs\PROJECTS\LARAVEL\policyApp\resources\views/admin/login.blade.php ENDPATH**/ ?>